package main

import (
    "net/http"
    "fmt"
    "log"
)

func main() {
    http.HandleFunc("/", func(writer http.ResponseWriter, request *http.Request) {
        fmt.Fprint(writer, "Go Web Hello World!")
    })
    log.Fatal(http.ListenAndServe(":8082",nil))
}
